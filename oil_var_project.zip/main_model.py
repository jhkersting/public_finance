
import numpy as np
import pandas as pd
from scipy.stats import norm
from arch import arch_model


class OilVaRModel:
    """
    Multi-horizon VaR model for oil prices.
    Supports EWMA, GARCH, EGARCH.
    Input: DataFrame with ['date','price']
    """

    def __init__(self, df, date_col="date", price_col="price"):
        self.df_raw = df.copy()
        self.date_col = date_col
        self.price_col = price_col
        self.df = None

    def prepare(self):
        df = self.df_raw.copy()
        df[self.date_col] = pd.to_datetime(df[self.date_col])
        df = df.sort_values(self.date_col)
        df["log_return"] = np.log(df[self.price_col] / df[self.price_col].shift(1))
        df = df.dropna()
        df["ret_pct"] = df["log_return"] * 100.0
        self.df = df.reset_index(drop=True)
        return self.df

    def _fit_garch(self, dist="t"):
        model = arch_model(
            self.df["ret_pct"],
            mean="Constant",
            vol="GARCH",
            p=1,
            q=1,
            dist=dist
        )
        return model.fit(disp="off")

    def _fit_egarch(self, dist="t"):
        model = arch_model(
            self.df["ret_pct"],
            mean="Constant",
            vol="EGARCH",
            p=1,
            o=1,
            q=1,
            dist=dist
        )
        return model.fit(disp="off")

    def _ewma_vol(self, lam=0.94):
        r = self.df["ret_pct"].values
        var = np.var(r, ddof=1)
        for i in range(1, len(r)):
            var = lam * var + (1 - lam) * r[i - 1] ** 2
        return np.sqrt(var)

    def multi_day_var(self, days=1, alpha=0.05, model="garch"):
        """
        Returns X-day VaR forecast in percent return units.
        """
        if self.df is None:
            self.prepare()

        if model.lower() == "ewma":
            vol_1d = self._ewma_vol()
            mean_1d = 0.0
            var_1d = norm.ppf(alpha) * vol_1d
            return mean_1d * days + var_1d * np.sqrt(days)

        elif model.lower() == "garch":
            res = self._fit_garch()
        elif model.lower() == "egarch":
            res = self._fit_egarch()
        else:
            raise ValueError("Model must be ewma, garch, or egarch")

        forecast = res.forecast(horizon=days)
        mean_path = forecast.mean.iloc[-1].values
        var_path = forecast.variance.iloc[-1].values

        cum_mean = mean_path.sum()
        cum_var = var_path.sum()

        vol = np.sqrt(cum_var)

        std_resid = (self.df["ret_pct"] - res.params.get("mu", 0.0)) / res.conditional_volatility
        q = np.quantile(std_resid, alpha)

        return cum_mean + q * vol
