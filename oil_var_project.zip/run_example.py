
import pandas as pd
from main_model import OilVaRModel

# Load your CSV here
df = pd.read_csv("oil_prices.csv")

model = OilVaRModel(df)
model.prepare()

# Example: 5-day VaR
var_5d = model.multi_day_var(days=5, alpha=0.05, model="garch")
print("5-Day 95% VaR (% return):", var_5d)

# Example: 10-day VaR with EGARCH
var_10d = model.multi_day_var(days=10, alpha=0.05, model="egarch")
print("10-Day 95% VaR (% return):", var_10d)

# Example: EWMA
var_5d_ewma = model.multi_day_var(days=5, alpha=0.05, model="ewma")
print("5-Day 95% VaR EWMA (% return):", var_5d_ewma)
