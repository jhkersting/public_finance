
Oil Multi-Horizon VaR Project

Files:
- oil_var_model.py  -> Core GARCH / EGARCH multi-day VaR engine
- run_model.py      -> Simple example runner
- sample_oil_data.csv -> Example dataset
- requirements.txt  -> Python dependencies

How to run:

1. Install dependencies:
   pip install -r requirements.txt

2. Run:
   python run_model.py

Modify horizon in run_model.py to compute X-day VaR.
