"""Utility functions for VaR and volatility model evaluation."""

from __future__ import annotations

from typing import Iterable, Tuple

import numpy as np
import pandas as pd
from scipy.stats import norm


def clean_numeric_series(values: Iterable[float] | pd.Series) -> pd.Series:
    """Convert input to a finite numeric pandas Series."""
    series = pd.Series(values, copy=False)
    numeric = pd.to_numeric(series, errors="coerce")
    numeric = numeric.replace([np.inf, -np.inf], np.nan).dropna()
    return numeric.astype(float)


def safe_quantile(values: Iterable[float] | pd.Series, q: float) -> float:
    """Compute a robust quantile that handles empty and dirty inputs."""
    clean = clean_numeric_series(values)
    if clean.empty:
        return float("nan")
    q = float(np.clip(q, 0.0, 1.0))
    return float(np.nanquantile(clean.to_numpy(), q))


def rolling_volatility(
    returns: Iterable[float] | pd.Series,
    window: int,
    min_periods: int | None = None,
) -> pd.Series:
    """Compute rolling sample volatility."""
    series = pd.Series(returns, copy=False)
    if min_periods is None:
        min_periods = max(2, min(window, 5))
    return series.rolling(window=window, min_periods=min_periods).std(ddof=1)


def calculate_qlike(
    realized_variance: Iterable[float] | pd.Series,
    forecast_variance: Iterable[float] | pd.Series,
    eps: float = 1e-10,
) -> pd.Series:
    """Calculate QLIKE loss in a numerically stable way."""
    realized = pd.to_numeric(pd.Series(realized_variance), errors="coerce")
    forecast = pd.to_numeric(pd.Series(forecast_variance), errors="coerce")
    aligned = pd.concat([realized, forecast], axis=1).dropna()
    aligned.columns = ["realized", "forecast"]
    if aligned.empty:
        return pd.Series(dtype=float)

    rv = np.clip(aligned["realized"].to_numpy(dtype=float), eps, None)
    fv = np.clip(aligned["forecast"].to_numpy(dtype=float), eps, None)
    ratio = rv / fv
    qlike = ratio - np.log(ratio) - 1.0
    return pd.Series(qlike, index=aligned.index, dtype=float)


def diebold_mariano_test(
    loss_1: Iterable[float] | pd.Series,
    loss_2: Iterable[float] | pd.Series,
    horizon: int = 1,
) -> Tuple[float, float]:
    """
    Diebold-Mariano test for equal predictive accuracy.

    Returns:
        (dm_statistic, two_sided_p_value)
    """
    l1 = clean_numeric_series(loss_1)
    l2 = clean_numeric_series(loss_2)
    d = pd.concat([l1, l2], axis=1).dropna()
    if d.empty or d.shape[0] < 5:
        return float("nan"), float("nan")

    diff = d.iloc[:, 0].to_numpy(dtype=float) - d.iloc[:, 1].to_numpy(dtype=float)
    n = diff.size
    mean_diff = float(np.mean(diff))
    demeaned = diff - mean_diff

    horizon = int(max(1, horizon))
    gamma0 = float(np.dot(demeaned, demeaned) / n)
    long_run_var = gamma0
    for lag in range(1, min(horizon, n - 1)):
        cov = float(np.dot(demeaned[lag:], demeaned[:-lag]) / n)
        weight = 1.0 - lag / horizon
        long_run_var += 2.0 * weight * cov

    long_run_var = max(long_run_var, 1e-12)
    dm_stat = mean_diff / np.sqrt(long_run_var / n)
    p_value = 2.0 * (1.0 - norm.cdf(abs(dm_stat)))
    return float(dm_stat), float(p_value)
