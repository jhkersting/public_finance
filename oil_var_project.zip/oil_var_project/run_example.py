"""Example runner for the oil VaR research package."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pandas as pd

from ml_var_model import MLVaRModel
from oil_var_model import OilRiskPipeline
from utils import diebold_mariano_test


def main() -> None:
    np.random.seed(42)

    project_dir = Path(__file__).resolve().parent
    input_path = project_dir / "sample_oil_prices.csv"

    pipeline = OilRiskPipeline(csv_path=input_path, random_state=42)
    data = pipeline.prepare_data()

    train_size = max(400, int(len(data) * 0.70))
    alpha = 0.01

    param_backtest = pipeline.rolling_backtest(
        train_size=train_size,
        alpha=alpha,
        refit_every=20,
        ewma_lambda=0.94,
        garch_dist="t",
        egarch_dist="t",
    )

    garch_backtest = param_backtest[param_backtest["model"] == "GARCH"].copy()
    garch_vol_feature = garch_backtest.set_index("date")["forecast_vol_pct"].reindex(data.index)
    garch_var_feature = garch_backtest.set_index("date")["forecast_var_pct"].reindex(data.index)

    ml_model = MLVaRModel(
        alpha=alpha,
        lookback=600,
        random_state=42,
        include_garch_feature=True,
        hybrid_weight=0.25,
    )
    ml_backtest = ml_model.rolling_backtest(
        data=data,
        train_size=train_size,
        refit_every=20,
        horizon_days=1,
        garch_vol_feature=garch_vol_feature,
        parametric_var_feature=garch_var_feature,
    )

    backtest_results = (
        pd.concat([param_backtest, ml_backtest], ignore_index=True)
        .sort_values(["date", "model"])
        .reset_index(drop=True)
    )

    var_test_summary = pipeline.var_test_summary(backtest_results, alpha=alpha)
    validation_summary = pipeline.validation_summary(backtest_results)
    residual_diagnostics = pipeline.residual_diagnostics(backtest_results)

    # Optional model comparison: DM test using QLIKE losses
    garch_loss = (
        backtest_results[backtest_results["model"] == "GARCH"]
        .set_index("date")["qlike"]
        .sort_index()
    )
    ml_loss = (
        backtest_results[backtest_results["model"] == "ML_QUANTILE"]
        .set_index("date")["qlike"]
        .sort_index()
    )
    aligned = pd.concat([garch_loss, ml_loss], axis=1, keys=["garch", "ml"]).dropna()
    dm_stat, dm_p = diebold_mariano_test(aligned["garch"], aligned["ml"], horizon=1)

    var_5_day = pipeline.forecast_var_x_days(
        horizon_days=5,
        alpha=alpha,
        ewma_lambda=0.94,
        garch_dist="t",
        egarch_dist="t",
    )

    backtest_results.to_csv(project_dir / "backtest_results.csv", index=False)
    validation_summary.to_csv(project_dir / "validation_summary.csv", index=False)
    var_test_summary.to_csv(project_dir / "var_test_summary.csv", index=False)

    print("VaR Test Summary")
    print(var_test_summary.to_string(index=False))
    print("\nValidation Summary")
    print(validation_summary.to_string(index=False))
    print("\nResidual Diagnostics")
    print(residual_diagnostics.to_string(index=False))
    print("\nDiebold-Mariano Test (QLIKE: GARCH vs ML_QUANTILE)")
    print(f"DM statistic: {dm_stat:.4f}, p-value: {dm_p:.4f}")
    print("\n5-Day VaR Forecast (%)")
    print(var_5_day.to_string(index=False))


if __name__ == "__main__":
    main()
