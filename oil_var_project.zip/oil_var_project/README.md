# Oil VaR Research Package

## Overview
This project provides a professional, modular Value-at-Risk (VaR) research framework for oil prices. It includes:
- Parametric volatility/VaR models (EWMA, GARCH(1,1), EGARCH(1,1,1))
- Student-t or normal innovation options
- Rolling backtesting and VaR coverage tests
- Forecast evaluation (MSE/RMSE/MAE/QLIKE/hit rate)
- ML quantile VaR (Gradient Boosting quantile regression)
- Multi-day (X-day) cumulative VaR forecasting

The package is deterministic (`random_state=42`) and includes robust fallback behavior if optimizers fail or sample size is small.

## Folder Structure
```
oil_var_project/
├── oil_var_model.py
├── ml_var_model.py
├── run_example.py
├── sample_oil_prices.csv
├── README.md
├── requirements.txt
└── utils.py
```

## Installation
```bash
cd /Users/jhkersting/Desktop/oil_var_project
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Example Usage
```bash
python run_example.py
```

The script:
1. Loads `sample_oil_prices.csv`
2. Runs EWMA, GARCH, EGARCH, and ML quantile VaR models
3. Performs rolling backtesting
4. Prints VaR tests, validation summary, and residual diagnostics
5. Exports:
   - `backtest_results.csv`
   - `validation_summary.csv`
   - `var_test_summary.csv`
6. Demonstrates a 5-day VaR forecast

## Methodology Notes
### VaR
VaR at confidence level `1 - alpha` is the left-tail quantile of returns. If realized return is below forecast VaR, that day is a VaR exception (hit).

### Kupiec Test (Unconditional Coverage)
Checks whether the observed exception rate matches the expected rate (`alpha`).
- Null: model has correct unconditional exception probability.

### Christoffersen Independence Test
Checks whether exceptions are independent over time.
- Null: no clustering of exceptions.

### Conditional Coverage Test
Combines Kupiec and independence into one test.
- Null: both correct frequency and independence hold.

### QLIKE
Variance forecast loss:
\[
QLIKE = \frac{RV_t}{\hat{V}_t} - \log\left(\frac{RV_t}{\hat{V}_t}\right) - 1
\]
where `RV_t` is realized variance proxy (`r_t^2`) and `\hat{V}_t` is forecast variance. Lower is better.

### X-Day VaR Logic
- EWMA: uses one-day variance and applies `sqrt(h)` scaling for volatility.
- GARCH/EGARCH: uses model-based horizon forecasts (`horizon=h`) and aggregates mean/variance across forecast days.
- Reported VaR is cumulative return VaR in percent.

### ML Quantile Approach
`MLVaRModel` uses:
- `GradientBoostingRegressor(loss="quantile", alpha=...)`
- Features: lagged returns, rolling 5d/20d vol, EWMA vol, optional GARCH vol
- Rolling retraining on a moving window
- Optional hybrid adjustment: blend ML quantile with parametric VaR forecast

## Interpretation Guidance
- `actual_rate` close to `expected_rate` with high Kupiec p-value indicates acceptable exception frequency.
- Low independence p-value can indicate clustered misses during stress regimes.
- Lower QLIKE and MAE/MSE suggest better volatility forecasting quality.
- Compare model trade-offs:
  - Parametric models may be more stable/explainable.
  - ML quantile can adapt to nonlinear structure and regime changes.
- Use X-day VaR for risk horizons beyond one day; avoid naive scaling for non-EWMA models.

## Data
`sample_oil_prices.csv` is synthetic (1500 daily observations), generated to include:
- Volatility clustering
- Regime shift
- Fat tails

Columns follow the required schema:
- `date`
- `price`
