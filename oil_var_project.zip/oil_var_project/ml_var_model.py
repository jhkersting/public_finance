"""Machine-learning quantile VaR model."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np
import pandas as pd
from scipy.stats import norm
from sklearn.ensemble import GradientBoostingRegressor

from utils import calculate_qlike, rolling_volatility, safe_quantile


@dataclass
class _ModelConfig:
    n_estimators: int = 300
    learning_rate: float = 0.03
    max_depth: int = 3
    min_samples_leaf: int = 8


class MLVaRModel:
    """Rolling quantile boosting model for direct VaR estimation."""

    def __init__(
        self,
        alpha: float = 0.01,
        lookback: int = 500,
        random_state: int = 42,
        include_garch_feature: bool = True,
        hybrid_weight: float = 0.20,
        config: Optional[_ModelConfig] = None,
    ) -> None:
        self.alpha = float(np.clip(alpha, 1e-4, 0.25))
        self.lookback = int(max(60, lookback))
        self.random_state = int(random_state)
        self.include_garch_feature = bool(include_garch_feature)
        self.hybrid_weight = float(np.clip(hybrid_weight, 0.0, 1.0))
        self.config = config or _ModelConfig()
        np.random.seed(self.random_state)

    @staticmethod
    def _ewma_volatility_series(returns: pd.Series, lam: float = 0.94) -> pd.Series:
        clean = pd.to_numeric(returns, errors="coerce").replace([np.inf, -np.inf], np.nan)
        arr = clean.to_numpy(dtype=float)
        out = np.full(shape=arr.shape, fill_value=np.nan, dtype=float)

        valid = np.isfinite(arr)
        if valid.sum() < 2:
            return pd.Series(out, index=returns.index)

        init_var = np.nanvar(arr[: min(30, arr.shape[0])])
        var = max(init_var, 1e-8)
        for i, val in enumerate(arr):
            if not np.isfinite(val):
                out[i] = np.sqrt(var)
                continue
            var = lam * var + (1.0 - lam) * (val * val)
            out[i] = np.sqrt(max(var, 1e-12))
        return pd.Series(out, index=returns.index)

    @staticmethod
    def _future_cumulative_returns(returns: pd.Series, horizon_days: int) -> pd.Series:
        horizon_days = int(max(1, horizon_days))
        cum = pd.Series(0.0, index=returns.index, dtype=float)
        for k in range(horizon_days):
            cum = cum + returns.shift(-k)
        return cum

    def _build_feature_frame(
        self,
        data: pd.DataFrame,
        horizon_days: int = 1,
        garch_vol_feature: Optional[pd.Series] = None,
    ) -> pd.DataFrame:
        if "return_pct" not in data.columns:
            raise ValueError("Input data must contain 'return_pct' column.")

        r = pd.to_numeric(data["return_pct"], errors="coerce")

        features = pd.DataFrame(index=data.index)
        features["lag_ret_1"] = r.shift(1)
        features["lag_ret_2"] = r.shift(2)
        features["lag_ret_5"] = r.shift(5)
        features["roll_vol_5"] = rolling_volatility(r, window=5).shift(1)
        features["roll_vol_20"] = rolling_volatility(r, window=20).shift(1)
        features["ewma_vol"] = self._ewma_volatility_series(r).shift(1)

        if self.include_garch_feature and garch_vol_feature is not None:
            aligned_garch = pd.to_numeric(garch_vol_feature.reindex(features.index), errors="coerce")
            features["garch_vol"] = aligned_garch.shift(1).fillna(features["ewma_vol"])

        target = self._future_cumulative_returns(r, horizon_days=horizon_days)
        frame = features.copy()
        frame["target_return_pct"] = target

        frame = frame.replace([np.inf, -np.inf], np.nan).dropna()
        return frame

    def rolling_backtest(
        self,
        data: pd.DataFrame,
        train_size: int,
        refit_every: int = 20,
        horizon_days: int = 1,
        garch_vol_feature: Optional[pd.Series] = None,
        parametric_var_feature: Optional[pd.Series] = None,
    ) -> pd.DataFrame:
        """Run rolling quantile backtest and produce VaR-style output schema."""
        frame = self._build_feature_frame(
            data=data,
            horizon_days=horizon_days,
            garch_vol_feature=garch_vol_feature,
        )

        columns = [
            "date",
            "model",
            "realized_return_pct",
            "forecast_mean_pct",
            "forecast_vol_pct",
            "forecast_variance_pct2",
            "forecast_var_pct",
            "hit",
            "hit_loss",
            "realized_var_proxy",
            "sq_error_var",
            "abs_error_var",
            "qlike",
            "horizon_days",
        ]

        if frame.empty:
            return pd.DataFrame(columns=columns)

        train_size = int(max(80, train_size))
        refit_every = int(max(1, refit_every))

        if len(frame) <= train_size:
            train_size = max(80, int(len(frame) * 0.60))
            if len(frame) <= train_size:
                return pd.DataFrame(columns=columns)

        feature_cols: List[str] = [c for c in frame.columns if c != "target_return_pct"]
        X = frame[feature_cols]
        y = frame["target_return_pct"]

        parametric = None
        if parametric_var_feature is not None:
            parametric = pd.to_numeric(parametric_var_feature.reindex(frame.index), errors="coerce")

        model: Optional[GradientBoostingRegressor] = None
        fallback_q = float(safe_quantile(y.iloc[:train_size], self.alpha))
        z_alpha = float(norm.ppf(np.clip(self.alpha, 1e-6, 1 - 1e-6)))

        rows: List[Dict[str, float | int | str | pd.Timestamp]] = []

        for i in range(train_size, len(frame)):
            step = i - train_size
            train_start = max(0, i - self.lookback)

            if model is None or step % refit_every == 0:
                X_train = X.iloc[train_start:i]
                y_train = y.iloc[train_start:i]

                if len(X_train) < 60:
                    continue

                model = GradientBoostingRegressor(
                    loss="quantile",
                    alpha=self.alpha,
                    n_estimators=self.config.n_estimators,
                    learning_rate=self.config.learning_rate,
                    max_depth=self.config.max_depth,
                    min_samples_leaf=self.config.min_samples_leaf,
                    random_state=self.random_state,
                )

                try:
                    model.fit(X_train, y_train)
                    fallback_q = float(safe_quantile(y_train, self.alpha))
                except Exception:
                    model = None

            x_row = X.iloc[[i]]
            if model is not None:
                try:
                    q_ml = float(model.predict(x_row)[0])
                except Exception:
                    q_ml = fallback_q
            else:
                q_ml = fallback_q

            q_final = q_ml
            if parametric is not None:
                q_param = parametric.iloc[i]
                if np.isfinite(q_param):
                    q_final = (1.0 - self.hybrid_weight) * q_ml + self.hybrid_weight * float(q_param)

            realized = float(y.iloc[i])
            hit = int(realized < q_final)
            hit_loss = float(max(q_final - realized, 0.0)) if hit else 0.0

            sigma_proxy = abs(q_final / z_alpha) if np.isfinite(z_alpha) and z_alpha != 0 else abs(q_final)
            sigma_proxy = float(max(sigma_proxy, 1e-8))
            var_proxy = sigma_proxy**2
            realized_var_proxy = realized**2

            sq_error = (var_proxy - realized_var_proxy) ** 2
            abs_error = abs(var_proxy - realized_var_proxy)
            qlike = float(calculate_qlike([realized_var_proxy], [var_proxy]).iloc[0])

            rows.append(
                {
                    "date": frame.index[i],
                    "model": "ML_QUANTILE",
                    "realized_return_pct": realized,
                    "forecast_mean_pct": 0.0,
                    "forecast_vol_pct": sigma_proxy,
                    "forecast_variance_pct2": var_proxy,
                    "forecast_var_pct": q_final,
                    "hit": hit,
                    "hit_loss": hit_loss,
                    "realized_var_proxy": realized_var_proxy,
                    "sq_error_var": sq_error,
                    "abs_error_var": abs_error,
                    "qlike": qlike,
                    "horizon_days": horizon_days,
                }
            )

        out = pd.DataFrame(rows, columns=columns)
        out["date"] = pd.to_datetime(out["date"])
        return out
