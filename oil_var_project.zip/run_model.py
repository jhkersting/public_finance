
import pandas as pd
from oil_var_model import OilMultiHorizonVaR

# Load your oil price CSV here
df = pd.read_csv("sample_oil_data.csv")

model = OilMultiHorizonVaR(df)

model.fit_garch()
model.fit_egarch()

# Example: 5-day VaR at 95%
result_garch = model.forecast_var(model="garch", horizon=5, alpha=0.05)
result_egarch = model.forecast_var(model="egarch", horizon=5, alpha=0.05)

print("GARCH 5-day VaR:", result_garch)
print("EGARCH 5-day VaR:", result_egarch)
