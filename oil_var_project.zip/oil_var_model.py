
import numpy as np
import pandas as pd
from scipy.stats import norm
from arch import arch_model


class OilMultiHorizonVaR:
    def __init__(self, df, date_col="date", price_col="price", return_scale=100.0):
        self.df = df.copy()
        self.date_col = date_col
        self.price_col = price_col
        self.return_scale = return_scale
        self._prepare()

    def _prepare(self):
        df = self.df
        df[self.date_col] = pd.to_datetime(df[self.date_col])
        df = df.sort_values(self.date_col)
        df["log_return"] = np.log(df[self.price_col] / df[self.price_col].shift(1))
        df = df.dropna()
        df["ret_pct"] = df["log_return"] * self.return_scale
        self.df = df.reset_index(drop=True)

    def fit_garch(self, dist="t"):
        r = self.df["ret_pct"].values
        self.garch_model = arch_model(r, mean="Constant", vol="GARCH", p=1, q=1, dist=dist).fit(disp="off")

    def fit_egarch(self, dist="t"):
        r = self.df["ret_pct"].values
        self.egarch_model = arch_model(r, mean="Constant", vol="EGARCH", p=1, o=1, q=1, dist=dist).fit(disp="off")

    def forecast_var(self, model="garch", horizon=1, alpha=0.05):
        if model.lower() == "garch":
            res = self.garch_model
        elif model.lower() == "egarch":
            res = self.egarch_model
        else:
            raise ValueError("Model must be 'garch' or 'egarch'")

        f = res.forecast(horizon=horizon)
        mean_forecast = f.mean.iloc[-1].sum()
        var_forecast = f.variance.iloc[-1].sum()
        vol_forecast = np.sqrt(var_forecast)

        mu = res.params.get("mu", 0.0)
        cond_vol = res.conditional_volatility
        std_resid = (self.df["ret_pct"].values - mu) / cond_vol
        q_alpha = np.quantile(std_resid, alpha)

        var_pct = mean_forecast + q_alpha * vol_forecast

        return {
            "horizon_days": horizon,
            "mean_pct": mean_forecast,
            "vol_pct": vol_forecast,
            "VaR_pct": var_pct
        }
