
# Oil Multi-Horizon VaR Project

## Files
- main_model.py → Core multi-day VaR engine
- run_example.py → Simple runner
- requirements.txt → Python dependencies

## Install
pip install -r requirements.txt

## Input Data
CSV must contain:
date,price

## Usage
python run_example.py

## Output
Returns X-day VaR in percent return terms.
Convert to dollar VaR:

Dollar_VaR = Position_Value * abs(VaR_pct / 100)
